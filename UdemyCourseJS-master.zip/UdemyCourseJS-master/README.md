# UdemyJSCourse 👋
[![Twitter: alkastras0704](https://img.shields.io/twitter/follow/alkastras0704.svg?style=social)](https://twitter.com/alkastras0704)

> Study course Udemy Javascript by Ivan Petrichenko
***
